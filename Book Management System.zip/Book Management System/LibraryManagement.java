package com.java.mini;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

class Book
{
	int id;
	String title;
	String author;
	Book(int id,String title, String author)
	{
		this.id=id;
		this.title=title;
		this.author=author;
	}
}

public class LibraryManagement {
	
	static ArrayList<Book> books = new ArrayList<>();
	static ArrayList<Book> issuedBooks = new ArrayList<>();
	static Scanner scan = new Scanner(System.in);
	
	static Connection con;
	
	static void connectToDatabase() throws SQLException, ClassNotFoundException
	{
		String url="your url";
		String user="your username";
		String password="your password";
		
		Class.forName("com.mysql.cj.jdbc.Driver");
		con=DriverManager.getConnection(url, user, password);
		
		System.out.println("Connected to MySQL");
	}
	
	static void closeConnection() throws SQLException
	{
		if(con!=null)
			con.close();
	}
	
	public static void main(String[] args) throws SQLException, ClassNotFoundException 
	{
		connectToDatabase();
		int choice;
		do {
		System.out.println("\n---------Library Menu----------");
		System.out.println("1. Add Books");
		System.out.println("2. Show Books");
		System.out.println("3. Issue Books");
		System.out.println("4. Return Books");
		System.out.println("5. Exit\n");
		System.out.print("Enter the number: ");
		choice= scan.nextInt();
		scan.nextLine();
		
		switch(choice)
		{
		case 1:
			addBook();
			break;
		case 2:
			showBook();
			break;
		case 3:
			issueBook();
			break;
		case 4:
			returnBook();
			break;
		case 5:
			System.out.println("Library Closed----");
			break;
		default:
			System.out.println("Invalid Choice!!!! Try Again");
		}
		
		}while(choice!=5);
		closeConnection();
	}
	static void addBook()
	{
		System.out.println("\nAdding Books:");
		System.out.println("Enter Book ID:");
		int id=scan.nextInt();
		scan.nextLine();
		System.out.println("Enter the book title:");
		String title = scan.nextLine();
		System.out.println("Enter the book author:");
		String author = scan.nextLine();
		try
		{
		String query="INSERT INTO books(id, title, author) VALUES(?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1, id);
		ps.setString(2, title);
		ps.setString(3, author);
		ps.executeUpdate();
		ps.close();
		System.out.println("Book added to DB");
		}
		catch(Exception  e)
		{
			if(e.getMessage().contains("Duplicate entry"))
			{
				System.out.println("This Book ID already Registered");
			}
			else
			{
				System.out.println("Failed to add DB"+e.getMessage());
			}
		}
		
	}
	
	static void showBook() throws SQLException
	{
		String query="SELECT * FROM books";
		
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(query);
		
		System.out.println("\nBooks in Lirary");
		
		boolean found = false;
		
		while(rs.next())
		{
			int id = rs.getInt("id");
			String title = rs.getString("title");
			String author = rs.getString("author");
			
			System.out.println(id + " - " + title + " By " + author);
			
			found = true;
		}
		
		if(!found)
		{
			System.out.println("No Books available");
		}
		
		rs.close();
		stmt.close();
	}
	
	static void issueBook() throws SQLException
	{
		System.out.println("\nBook issuing:");
		System.out.println("Enter Book ID:");
		int id = scan.nextInt();
		scan.nextLine();
//		System.out.println("Enter Book Title:");
//		String title=scan.nextLine();
		try
		{
		String query="DELETE FROM books WHERE id=?";
		
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
		System.out.println("Book issued and removed from DB");
		}
		catch(Exception e)
		{
			System.out.println("Failure to Update DB: " + e.getMessage());
		}
		
	}
	
	static void returnBook()
	{
		System.out.println("Returning Books");
		System.out.println("Enter Book ID:");
		int id=scan.nextInt();
		scan.nextLine();
		System.out.println("Enter the book title:");
		String title = scan.nextLine();
		System.out.println("Enter the book author:");
		String author = scan.nextLine();

		try
		{
	    // Check if book already exist
		String check = "SELECT * FROM books WHERE id=?";
		PreparedStatement pcheck = con.prepareStatement(check);
		pcheck.setInt(1, id);
		ResultSet rs = pcheck.executeQuery();
		
		if(rs.next())
		{
			System.out.println("The Book ID already exist in the library");
		}
		else
		{
		String query="INSERT INTO books(id, title, author) VALUES(?,?,?)";
		
		PreparedStatement ps = con.prepareStatement(query);
		ps.setInt(1, id);
		ps.setString(2, title);
		ps.setString(3, author);
		ps.executeUpdate();
		ps.close();
		System.out.println("Book returned to DB");
		}
		}
		catch(Exception  e)
		{
			System.out.println(e.getMessage());
		}
		
		
	
	}

}
