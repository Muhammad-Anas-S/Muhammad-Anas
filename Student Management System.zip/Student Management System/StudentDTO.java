package com.example.studentmanagement.controller;

public class StudentDTO 
{
	int id;
	String name;
	String email;
	
	public StudentDTO()
	{
		
	}
	public StudentDTO(int id,String name,String email)
	{
		this.id=id;
		this.name=name;
		this.email=email;
	}
	
	public void setID(int id)
	{
		this.id=id;
	}
	public int getID()
	{
		return id;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}

	public void setEmail(String email)
	{
		this.email=email;
	}
	public String getEmail()
	{
		return email;
	}
}
