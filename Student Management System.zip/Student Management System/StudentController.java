package com.example.studentmanagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.studentmanagement.model.Student;
import com.example.studentmanagement.service.StudentService;

@RestController
@RequestMapping("/students")
public class StudentController 
{
	@Autowired
	StudentService studentService;
	
	@PostMapping
	public ResponseEntity<String> addStudent(@RequestBody Student student)
	{
		studentService.saveStudent(student);
		return ResponseEntity.ok("Student Added Successfully...");
	}
	
	@GetMapping
	public ResponseEntity<?> displayAllStudent()
	{
		List<StudentDTO> students = studentService.getAllStudents();
		
		if(students.isEmpty())
		{
			return ResponseEntity.ok("No Students Available");
		}
		else
		{
			return ResponseEntity.ok(students);
		}
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<?> displayStudentByID(@PathVariable int id)
	{
		StudentDTO dto = studentService.getStudentByID(id);

		if(dto == null)
		{
			return ResponseEntity.status(HttpStatus.NOT_FOUND).body("Student id no." + id + " not found");
		}
		else
		{
			return ResponseEntity.ok(dto);
		}
	}
	
	@PutMapping("/{id}")
	public String updateStudent(@PathVariable int id, @RequestBody Student student)
	{
		Student updatedStudent = studentService.updateStudentByID(id, student);
		if(updatedStudent!=null)
		{
			return "Student updated Successfully...";
		}
		else
		{
			return "Student not found!";
		}
	}
	
	@DeleteMapping()
	public ResponseEntity<?> removeAllStudent()
	{
		studentService.deleteAllStudents();
		return ResponseEntity.ok("Removed all Successfully...");
	}
	
	@DeleteMapping("/{id}")
	public String removeStudent(@PathVariable int id)
	{
		return studentService.deleteStudentByID(id);
	}
		
}
