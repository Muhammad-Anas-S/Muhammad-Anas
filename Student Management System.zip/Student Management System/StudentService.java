package com.example.studentmanagement.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.studentmanagement.Repository.StudentRepository;
import com.example.studentmanagement.controller.StudentDTO;
import com.example.studentmanagement.model.Student;

@Service
public class StudentService 
{
	@Autowired
	StudentRepository srepository;
	
	//add student
	public Student saveStudent(Student student)
	{
		return srepository.save(student);
	}
	
	//Get All Students
	public List<StudentDTO> getAllStudents()
	{
		List<Student> student = srepository.findAll();
		List<StudentDTO> dtos= new ArrayList<>();
		for(Student s: student)
		{
			StudentDTO dto = new StudentDTO(s.getID(), s.getName(), s.getEmail());
			dtos.add(dto);
		}
		return dtos;
	}
	
	//Get Student By ID
	public StudentDTO getStudentByID(int id)
	{
		Optional<Student> student = srepository.findById(id);
		if(student.isPresent())
		{
			Student students = student.get();
			StudentDTO sdto = new StudentDTO(students.getID(),students.getName(),students.getEmail());
			return sdto;
		}
		return null;
	}
	
	//Update Student By ID
	public Student updateStudentByID(int id, Student updatedStudent)
	{
		Optional<Student> oldDetails= srepository.findById(id);
		
		if(oldDetails.isPresent())
		{
			Student student = oldDetails.get();
			student.setName(updatedStudent.getName());
			student.setPassword(updatedStudent.getPassword());
			student.setEmail(updatedStudent.getEmail());
			return srepository.save(student);
		}
		return null;		
	}
	
	//Delete Student By ID
	public String deleteStudentByID(int id)
	{
		Optional<Student> student = srepository.findById(id);
		if(student.isPresent())
		{
			srepository.deleteById(id);
			return "Removed Student Successfully";
		}
		else
		{
			return "Student ID not found";
		}
	}	
	
	//Delete All Students
	public void deleteAllStudents()
	{
		srepository.deleteAll();
	}
}
