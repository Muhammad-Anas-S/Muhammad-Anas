package com.example.studentmanagement.model;

import jakarta.persistence.*;

@Entity
public class Student 
{
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	
	@Column(unique=true)
	String password;
	String email;
	
	public Student()
	{
		
	}
	public Student(int id,String name,String password,String email)
	{
		this.id=id;
		this.name=name;
		this.password=password;
		this.email=email;
	}
	
	public void setID(int id)
	{
		this.id=id;
	}
	public int getID()
	{
		return id;
	}
	
	public void setName(String name)
	{
		this.name=name;
	}
	public String getName()
	{
		return name;
	}
	
	public void setPassword(String password)
	{
		this.password=password;
	}
	public String getPassword()
	{
		return password;
	}
	
	public void setEmail(String email)
	{
		this.email=email;
	}
	public String getEmail()
	{
		return email;
	}
}
